import { unified, type Plugin } from 'unified';
import remarkParse from 'remark-parse';
import remarkGfm from 'remark-gfm';
import type { Root } from 'mdast';
import { remarkPlainParagraph } from './plain-paragraph';

export type PreparedMode = 'filepaths' | 'plain' | 'preview';
interface Owner { readonly sessionId: string; readonly generation: number }
const defaults = { maxEntries: 64, maxChars: 160_000, maxSourceChars: 16_000, maxNodes: 8_000,
  maxGlobalEntries: 128, maxGlobalChars: 320_000, maxGlobalNodes: 16_000 };
// WHY: page preparation is optional; merely importing App must not construct
// another processor on startup when no first page is being loaded.
const createParser = () => unified().use(remarkParse).use(remarkGfm).use(remarkPlainParagraph).freeze();
let parser: ReturnType<typeof createParser> | undefined;

// WHY: a posted message yields to painting between small bounded sources; ports
// close after delivery, so a canceled page leaves no poll or permanent listener.
export function yieldPreparation(): Promise<void> {
  return new Promise(resolve => {
    const channel = new MessageChannel();
    channel.port1.onmessage = () => { channel.port1.close(); channel.port2.close(); resolve(); };
    channel.port2.postMessage(null);
  });
}

function nodeCount(tree: Root, limit: number): number {
  const stack: unknown[] = [tree];
  let total = 0;
  while (stack.length) {
    if (++total > limit) return total;
    const node = stack.pop() as { children?: unknown[] };
    if (node.children) stack.push(...node.children);
  }
  return total;
}

export function createPreparedMarkdown(limits: Partial<typeof defaults> = {}) {
  const budget = { ...defaults, ...limits };
  let generation = 0, globalEntries = 0, globalChars = 0, globalNodes = 0;
  let queue: Promise<void> = Promise.resolve();
  const owners = new Map<string, { owner: Owner; entries: Map<string, Root>; chars: number; nodes: number }>();
  const discard = (sessionId: string) => {
    const prior = owners.get(sessionId);
    if (!prior) return;
    globalEntries -= prior.entries.size; globalChars -= prior.chars; globalNodes -= prior.nodes;
    owners.delete(sessionId);
  };
  const valid = (owner: Owner) => owners.get(owner.sessionId)?.owner === owner;
  const begin = (sessionId: string): Owner => {
    discard(sessionId);
    const owner = { sessionId, generation: ++generation };
    owners.set(sessionId, { owner, entries: new Map(), chars: 0, nodes: 0 });
    return owner;
  };
  const release = (sessionId: string, owner?: Owner) => {
    if (!owner || valid(owner)) discard(sessionId);
  };
  const put = (owner: Owner, source: string, tree: Root, mode: PreparedMode = 'filepaths'): boolean => {
    const state = owners.get(owner.sessionId);
    if (!state || state.owner !== owner || source.length > budget.maxSourceChars || !source.length) return false;
    const key = `${mode}:${source}`;
    if (state.entries.has(key)) return true;
    const count = nodeCount(tree, budget.maxNodes + 1);
    if (state.entries.size >= budget.maxEntries || state.chars + source.length > budget.maxChars || state.nodes + count > budget.maxNodes
      || globalEntries >= budget.maxGlobalEntries || globalChars + source.length > budget.maxGlobalChars
      || globalNodes + count > budget.maxGlobalNodes) return false;
    // WHY: neither the preparer nor react-markdown may mutate the cache's AST.
    state.entries.set(key, structuredClone(tree));
    state.chars += source.length;
    state.nodes += count;
    globalEntries++; globalChars += source.length; globalNodes += count;
    return true;
  };
  const get = (sessionId: string, source: string, mode: PreparedMode): Root | null => {
    // WHY: a giant body must skip even key construction on the render path.
    if (source.length > budget.maxSourceChars) return null;
    const cached = owners.get(sessionId)?.entries.get(`${mode}:${source}`);
    if (!cached) return null;
    try { return structuredClone(cached); }
    catch { return null; } // a WebView without clone support uses the unchanged parser
  };
  const prepare = (owner: Owner, sources: readonly string[], yieldStep = yieldPreparation, mode: PreparedMode = 'filepaths') => {
    // WHY: one shared cooperative job prevents several IPC replies from parsing
    // back-to-back before paint. Yield before the FIRST source too. The chain
    // catches a failed job so subsequent pages still publish normally.
    const job = queue.then(async () => {
      for (const source of sources) {
        if (!valid(owner)) return;
        await yieldStep();
        if (!valid(owner)) return;
        const state = owners.get(owner.sessionId)!;
        if (!source.length || source.length > budget.maxSourceChars || state.entries.has(`${mode}:${source}`)
          || state.entries.size >= budget.maxEntries || state.chars + source.length > budget.maxChars
          || globalEntries >= budget.maxGlobalEntries || globalChars + source.length > budget.maxGlobalChars
          || state.nodes >= budget.maxNodes || globalNodes >= budget.maxGlobalNodes) continue;
        try { put(owner, source, (parser ??= createParser()).parse(source), mode); }
        catch { /* best effort: the unchanged parser renders this source at publication */ }
      }
    });
    queue = job.catch(() => {});
    return job;
  };
  return { begin, release, valid, put, get, prepare };
}

export const preparedMarkdown = createPreparedMarkdown();

// WHY: replace ONLY the parse result on a byte-exact owner/mode/source hit.
// ReactMarkdown still runs remark-rehype, every existing rehype plugin and its
// security URL transform/components. No processor, file or mutable AST is reused.
export const remarkPreparedMarkdown: Plugin<[{ owner: string; mode: PreparedMode; cache?: ReturnType<typeof createPreparedMarkdown> }], string, Root> = function (options) {
  const original = this.parser;
  if (!original) throw Error('remark-parse must precede markdown preparation');
  this.parser = (document, file) => options.cache?.get(options.owner, String(document), options.mode)
    ?? original(document, file);
};
