import { describe, expect, it, vi } from 'vitest';
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkGfm from 'remark-gfm';
import { createPreparedMarkdown, remarkPreparedMarkdown, yieldPreparation } from './prepared-markdown';

const baseline = unified().use(remarkParse).use(remarkGfm);
const source = '## Title\n\n```js\nconst x = 1\n```\n\nhttps://example.com/file.md';

describe('cooperative first-page markdown preparation', () => {
  it('posts a task between sources rather than completing in the same microtask', async () => {
    let done = false;
    const pending = yieldPreparation().then(() => { done = true; });
    await Promise.resolve();
    expect(done).toBe(false);
    await pending;
    expect(done).toBe(true);
  });
  it('yields between sources, clones independent trees, and misses when source or owner differs', async () => {
    const cache = createPreparedMarkdown();
    const owner = cache.begin('s');
    const yields: number[] = [];
    await cache.prepare(owner, [source, '![image](https://example.com/image.png)', '<details><summary>Read</summary>\n\nText\n\n</details>'], () => { yields.push(1); return Promise.resolve(); });
    expect(yields).toHaveLength(3);
    const hit = cache.get('s', source, 'filepaths');
    expect(hit).toStrictEqual(baseline.parse(source));
    const tree = baseline.parse('original');
    expect(cache.put(owner, 'original', tree)).toBe(true);
    (tree.children[0] as any).children[0].value = 'mutated outside cache';
    expect(cache.get('s', 'original', 'filepaths')).toStrictEqual(baseline.parse('original'));
    (hit!.children as any[]).splice(0);
    expect(cache.get('s', source, 'filepaths')).toStrictEqual(baseline.parse(source));
    expect(cache.get('other', source, 'filepaths')).toBeNull();
    expect(cache.get('s', source + 'x', 'filepaths')).toBeNull();
    expect(cache.get('s', source, 'preview')).toBeNull();
    cache.release('s');
    expect(cache.get('s', source, 'filepaths')).toBeNull();
  });

  it('falls back if cloning a hit fails rather than breaking the chat render', () => {
    const cache = createPreparedMarkdown();
    const owner = cache.begin('s');
    cache.put(owner, source, baseline.parse(source));
    const clone = globalThis.structuredClone;
    try {
      globalThis.structuredClone = (() => { throw Error('clone unavailable'); }) as typeof structuredClone;
      expect(cache.get('s', source, 'filepaths')).toBeNull();
    } finally { globalThis.structuredClone = clone; cache.release('s'); }
  });

  it('globally limits cache across owners and serializes page preparation with a pre-work yield', async () => {
    const cache = createPreparedMarkdown({ maxGlobalEntries: 1, maxGlobalChars: 80, maxGlobalNodes: 3 });
    const first = cache.begin('a'), second = cache.begin('b');
    const steps: Array<() => void> = [];
    const yieldStep = () => new Promise<void>(resolve => { steps.push(resolve); });
    const a = cache.prepare(first, ['alpha'], yieldStep);
    const b = cache.prepare(second, ['beta'], yieldStep);
    expect(cache.get('a', 'alpha', 'filepaths')).toBeNull(); // yield before first parse
    await vi.waitFor(() => expect(steps).toHaveLength(1)); // second owner cannot start its own work
    steps.shift()!();
    await Promise.resolve();
    expect(cache.get('a', 'alpha', 'filepaths')).not.toBeNull();
    // release first before the second job; global budget becomes available
    cache.release('a', first);
    await a;
    for (let i = 0; i < 5 && !steps.length; i++) await Promise.resolve();
    await vi.waitFor(() => expect(steps).toHaveLength(1));
    steps.shift()!();
    await b;
    expect(cache.get('b', 'beta', 'filepaths')).not.toBeNull();
    cache.release('a', first); // old owner cannot remove new generation
    const reopened = cache.begin('a');
    cache.release('a', first);
    expect(cache.valid(reopened)).toBe(true);
    cache.release('a', reopened);
    cache.release('b', second);
  });

  it('caps sources and memory, and canceled owners cannot commit a late parse', async () => {
    const cache = createPreparedMarkdown({ maxEntries: 1, maxChars: 80, maxSourceChars: 65 });
    const first = cache.begin('s');
    let resume!: () => void;
    const pending = cache.prepare(first, [source, 'short'], () => new Promise<void>(r => { resume = r; }));
    await vi.waitFor(() => expect(resume).toBeTypeOf('function'));
    cache.release('s');
    resume();
    await pending;
    expect(cache.get('s', source, 'filepaths')).toBeNull();
    const second = cache.begin('s');
    await cache.prepare(second, ['short', 'a'.repeat(100)], () => Promise.resolve());
    expect(cache.get('s', 'short', 'filepaths')).not.toBeNull();
    expect(cache.put(second, 'next', baseline.parse('next'))).toBe(false); // entry budget
    expect(cache.get('s', 'a'.repeat(100), 'filepaths')).toBeNull();
    const nodes = createPreparedMarkdown({ maxNodes: 2 });
    const nOwner = nodes.begin('n');
    expect(nodes.put(nOwner, 'x', baseline.parse('x'))).toBe(false); // root + paragraph + text > 2
    nodes.release('n');
    expect(first).not.toBe(second);
  });

  it('uses an exact prepared hit in the real parser attacher, delegating mismatches', () => {
    const cache = createPreparedMarkdown();
    const owner = cache.begin('s');
    cache.put(owner, source, baseline.parse(source));
    let parses = 0;
    const processor = unified().use(remarkParse).use(remarkGfm).use(function () {
      const original = this.parser!;
      this.parser = (doc, file) => { parses++; return original(doc, file); };
    }).use(remarkPreparedMarkdown, { owner: 's', mode: 'filepaths', cache });
    expect(processor.parse(source)).toStrictEqual(baseline.parse(source));
    expect(parses).toBe(0);
    expect(processor.parse(source + 'x')).toStrictEqual(baseline.parse(source + 'x'));
    expect(parses).toBe(1);
  });
});
