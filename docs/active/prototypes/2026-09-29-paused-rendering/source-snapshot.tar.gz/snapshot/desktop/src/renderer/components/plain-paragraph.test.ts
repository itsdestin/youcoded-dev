import { describe, expect, it } from 'vitest';
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkGfm from 'remark-gfm';
import { detectLinkTokens } from './markdown-linkify';
import { remarkPlainParagraph, literalParagraph } from './plain-paragraph';

const original = unified().use(remarkParse).use(remarkGfm);
let fallbackCount = 0;
const fast = unified().use(remarkParse).use(remarkGfm).use(function countParser(this: ReturnType<typeof unified>) {
  const parser = this.parser;
  if (!parser) throw Error('remark-parse not installed');
  this.parser = (value, file) => { fallbackCount++; return parser(value, file); };
}).use(remarkPlainParagraph);

const fixture = (n: number) => Array.from({ length: n }, (_, i) => `MIXED_TEXT:stream-1:${String(i).padStart(4, '0')}\n`).join('');

describe('literal paragraph remark parser', () => {
  it('keeps real mdast positions and values for the 1500-line fixture and incremental prefixes without calling micromark', () => {
    fallbackCount = 0;
    const full = fixture(1500);
    for (const input of [fixture(1), fixture(2), fixture(34), fixture(700), full, full.slice(0, -1), 'a', 'word_one:42']) {
      expect(literalParagraph(input)).not.toBeNull();
      expect(fast.parse(input)).toStrictEqual(original.parse(input));
    }
    expect(fallbackCount).toBe(0);
  });

  it('differentially checks generated eligible paragraphs and ending newline prefixes', () => {
    let seed = 3287;
    const pick = (n: number) => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed % n; };
    const words = ['MIXED_TEXT:stream-1:0000', 'word_one', 'A', 'abc-12', 'X:Y'];
    for (let i = 0; i < 120; i++) {
      const input = Array.from({ length: 1 + pick(20) }, () => words[pick(words.length)]).join('\n') + (pick(2) ? '\n' : '');
      expect(literalParagraph(input), input).not.toBeNull();
      expect(fast.parse(input), input).toStrictEqual(original.parse(input));
    }
  });

  it('delegates every uncertain boundary, syntax or path to the original parser unchanged', () => {
    const uncertain = ['', ' ', ' leading', 'a ', 'a  \nb', 'a\n\nb', 'a\n b', 'a\n    code', 'a\r\nb',
      'word_', '_word', 'a _ b', 'a*em*', 'a ~~b~~', 'a &amp;', 'a https://example.com',
      'a /home/user/file.md', 'a file.txt', 'a\\b', 'a\n# heading', 'a\n- list',
      'a\n1. list', 'a\n```js', 'a\n> quote', 'a\n<details>', 'a\n---', 'a\nline  ',
      'a\n\tcode', 'a\n\nend', 'a\n[link](x)', 'a\n!image'];
    for (const input of uncertain) {
      expect(literalParagraph(input), JSON.stringify(input)).toBeNull();
      expect(fast.parse(input), JSON.stringify(input)).toStrictEqual(original.parse(input));
    }
    expect(fallbackCount).toBe(uncertain.length);
    expect(detectLinkTokens(fixture(3), { filepaths: true })).toEqual([]);
  });
});
