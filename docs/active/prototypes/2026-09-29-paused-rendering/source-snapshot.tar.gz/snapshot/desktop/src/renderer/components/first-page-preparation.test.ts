import { expect, it } from 'vitest';
import { createPreparedMarkdown } from './prepared-markdown';
import { pageMarkdownSources, publishPreparedFirstPage } from './first-page-preparation';
import { createSessionChatState } from '../state/chat-types';
import { chatReducer } from '../state/chat-reducer';
import { pageEventToAction } from '../state/transcript-page-actions';
import { splitIntoBubbles } from './AssistantTurnBubble';
import { startStream, advanceStream, withDefinitions } from './markdown-blocks';
import type { TranscriptEvent } from '../../shared/types';

const events = [
  { type: 'assistant-text', uuid: 'a', data: { text: '## Header', partId: 'same' } },
  { type: 'assistant-text', uuid: 'b', data: { text: '\n\n[link](https://example.com)', partId: 'same' } },
  { type: 'tool-use', uuid: 'c', data: { toolUseId: 't', toolName: 'Read', toolInput: {} } },
  { type: 'assistant-text', uuid: 'd', data: { text: '```js\nconst a = 1\n```' } },
].map(e => ({ ...e, sessionId: 's', timestamp: 1 })) as TranscriptEvent[];

it('prepares sources actually consumed by reducer bubbles, not only raw events', () => {
  const sources = pageMarkdownSources(events);
  let state = new Map([['s', createSessionChatState()]]);
  for (const event of events) { const action = pageEventToAction(event); if (action) state = chatReducer(state, action); }
  const rendered = [...state.get('s')!.assistantTurns.values()].flatMap(t => splitIntoBubbles(t).map(b => b.text?.content).filter(Boolean));
  expect(rendered).toContain('## Header\n\n[link](https://example.com)');
  expect(rendered.every(source => sources.includes(source!))).toBe(true);
});

it('prepares exact painted stream group sources including definitions before optional whole source', async () => {
  const markdown = '## Plan\n\nSee [guide][ref] here.\n\n```js\nconst answer = 42\n```\n\n[ref]: https://example.com';
  const page = [{ ...events[0], data: { text: markdown } }] as TranscriptEvent[];
  const stream = advanceStream(startStream('## Plan'), markdown);
  const painted = stream.groups.filter(g => g.paints).map(g => withDefinitions(g.draw, g.defs));
  expect(painted.length).toBeGreaterThan(1);
  expect(painted.some(s => s.includes('[ref]: https://example.com'))).toBe(true);
  const sources = pageMarkdownSources(page);
  for (const source of painted) expect(sources, source).toContain(source);
  expect(sources).toContain(markdown);
  const cache = createPreparedMarkdown();
  const owner = cache.begin('s');
  await publishPreparedFirstPage(cache, owner, page, () => {}, () => Promise.resolve());
  for (const source of painted) expect(cache.get('s', source, 'filepaths'), source).not.toBeNull();
  cache.release('s');
});

it('never caches a truncated prefix from an oversized coalesced segment', () => {
  const huge = 'x'.repeat(16_000);
  const page = [
    { ...events[0], data: { text: huge, partId: 'same' } },
    { ...events[1], data: { text: 'tail', partId: 'same' } },
  ] as TranscriptEvent[];
  expect(pageMarkdownSources(page)).toEqual([]);
});

it('under an entry budget prioritizes most recent actual text sources', () => {
  const many = Array.from({ length: 70 }, (_, i) => ({ type: 'assistant-text', uuid: `uuid-${i}`, sessionId: 's', timestamp: i,
    data: { text: `Unique reply ${i}` } })) as TranscriptEvent[];
  const sources = pageMarkdownSources(many);
  expect(sources).toHaveLength(64);
  expect(sources[0]).toBe('Unique reply 69');
  expect(sources).not.toContain('Unique reply 0');
});

it('publishes original page even if best-effort preparation fails without altering events', async () => {
  const cache = createPreparedMarkdown();
  const owner = cache.begin('s');
  const before = structuredClone(events);
  const publications: TranscriptEvent[][] = [];
  await publishPreparedFirstPage(cache, owner, events, () => publications.push(events), () => Promise.reject(Error('no preparation channel')));
  expect(publications).toHaveLength(1);
  expect(publications[0]).toBe(events);
  expect(events).toStrictEqual(before);
  cache.release('s');
});

it('publishes once only after yielding preparation; stale close/reopen cannot publish or retain old sources', async () => {
  const cache = createPreparedMarkdown();
  const first = cache.begin('s');
  let resume!: () => void;
  const published: number[] = [];
  const pending = publishPreparedFirstPage(cache, first, events, () => { published.push(1); }, () => new Promise<void>(r => { resume = r; }));
  expect(published).toEqual([]);
  cache.release('s');
  const second = cache.begin('s');
  resume();
  await pending;
  expect(published).toEqual([]);
  expect(cache.get('s', events[0].data.text!, 'filepaths')).toBeNull();
  await publishPreparedFirstPage(cache, second, events, () => { published.push(2); }, () => Promise.resolve());
  expect(published).toEqual([2]);
  expect(cache.get('s', '## Header\n\n[link](https://example.com)', 'filepaths')).not.toBeNull();
  cache.release('s', second);
  expect(cache.get('s', '## Header\n\n[link](https://example.com)', 'filepaths')).toBeNull();
});
