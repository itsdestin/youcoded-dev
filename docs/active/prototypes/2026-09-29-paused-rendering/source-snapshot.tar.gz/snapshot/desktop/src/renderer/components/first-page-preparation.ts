import type { TranscriptEvent } from '../../shared/types';
import { preparedMarkdown, type createPreparedMarkdown, yieldPreparation } from './prepared-markdown';
import { advanceStream, startStream, withDefinitions } from './markdown-blocks';

type Cache = ReturnType<typeof createPreparedMarkdown>;
type Owner = ReturnType<Cache['begin']>;

// WHY: the reducer coalesces adjacent native text deltas by partId before
// AssistantTurnBubble passes the text segment to MarkdownContent. Enumerate
// both whole CC blocks and coalesced candidate text; byte-exact lookup means
// live/replay dedup or a different grouping can only MISS, never render wrong AST.
export function pageMarkdownSources(events: readonly TranscriptEvent[]): string[] {
  const sources: string[] = [];
  let part: string | undefined, current = '', oversized = false;
  const seen = new Set<string>();
  const flush = () => {
    if (!oversized && current && current.length <= 16_000) {
      // WHY: use the EXACT source MarkdownChunk gives ReactMarkdown, including
      // per-group link definitions. Cold mounts start as one document; a later
      // update may split that document, so include both painted-group candidates
      // and the original whole source. Never store a giant partial prefix.
      const firstLine = current.indexOf('\n');
      const stream = firstLine > 0
        ? advanceStream(startStream(current.slice(0, firstLine)), current)
        : startStream(current);
      const groups = stream.groups.filter(g => g.paints).map(g => withDefinitions(g.draw, g.defs));
      for (const source of [...groups, current]) {
        if (source.length > 16_000) continue;
        const prior = sources.indexOf(source);
        if (prior >= 0) sources.splice(prior, 1);
        if (sources.length === 64) sources.shift();
        sources.push(source);
      }
    }
    current = ''; part = undefined; oversized = false;
  };
  for (const event of events) {
    if (event.type !== 'assistant-text' || event.data.parentAgentToolUseId || (event.uuid && seen.has(event.uuid))) {
      flush(); continue;
    }
    if (event.uuid) seen.add(event.uuid);
    const text = event.data.text;
    if (typeof text !== 'string') { flush(); continue; }
    if (!part || part !== event.data.partId) flush();
    part = event.data.partId || undefined;
    // A giant body never enters the cache; do not create repeated growing copies.
    if (oversized) continue;
    if (current.length + text.length > 16_000) { current = ''; oversized = true; continue; }
    current += text;
  }
  flush();
  return sources.reverse();
}

export async function publishPreparedFirstPage(
  cache: Cache, owner: Owner, events: readonly TranscriptEvent[], publish: () => void,
  yieldStep = yieldPreparation,
): Promise<void> {
  // WHY: preparation is an optimization, never the source of page truth. A
  // canceled generation may finish a queued yield; it must never publish its
  // stale page or hold onto a newly reopened session's owner.
  try { await cache.prepare(owner, pageMarkdownSources(events), yieldStep); }
  catch { /* unexpected preparation error: render via unchanged parser */ }
  if (cache.valid(owner)) publish();
}

export const firstPageMarkdown = preparedMarkdown;
