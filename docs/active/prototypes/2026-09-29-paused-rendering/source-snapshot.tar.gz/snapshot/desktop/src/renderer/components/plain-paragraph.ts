import type { Root } from 'mdast';
import type { Plugin } from 'unified';
import { detectLinkTokens } from './markdown-linkify';

// WHY: these are only literal single-paragraph sources: no syntax punctuation,
// blank/indented lines, hard breaks, entities, links, paths, or edge underscores.
// Keep the whitelist intentionally narrow; everything uncertain uses micromark.
export function literalParagraph(source: string): Root | null {
  if (!source || /[^A-Za-z0-9_: \-\n]/.test(source)) return null;
  const body = source.endsWith('\n') ? source.slice(0, -1) : source;
  if (!body || /(^|\n)[^A-Za-z0-9]|[^A-Za-z0-9](\n|$)/.test(body)) return null;
  if (/(^|[^A-Za-z0-9])_|_([^A-Za-z0-9]|$)/.test(body)) return null;
  if (detectLinkTokens(source, { filepaths: true }).length) return null;
  const lines = body.split('\n');
  const end = { line: lines.length, column: lines.at(-1)!.length + 1, offset: body.length };
  const start = { line: 1, column: 1, offset: 0 };
  const position = { start, end };
  return { type: 'root', children: [{ type: 'paragraph', children: [{ type: 'text', value: body, position }], position }],
    position: { start, end: source.endsWith('\n') ? { line: lines.length + 1, column: 1, offset: source.length } : end } };
}

// WHY: swap only the parser, not the React element/component pipeline. The
// original parser handles all fallback sources with the same gfm configuration;
// no AST or file is cached across documents or streaming updates.
export const remarkPlainParagraph: Plugin<[], string, Root> = function () {
  const original = this.parser;
  if (!original) throw Error('remark-parse must precede the literal paragraph parser');
  this.parser = (document, file) => literalParagraph(String(document)) ?? original(document, file);
};
